import React, { useState } from 'react';
import questions from '../data/questions';
export default function QuestionPage() {
  const [visibleAnswers, setVisibleAnswers] = useState({});
  const toggleAnswer = (id) => setVisibleAnswers(prev => ({ ...prev, [id]: !prev[id] }));
  return (
    <div className="p-4 max-w-4xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Questões do Concurso CFS/25 - PMSP</h1>
      {questions.map((q, index) => (
        <div key={index} className="mb-6 p-4 border rounded-lg shadow">
          <h2 className="font-semibold mb-2">{index + 1}. {q.enunciado}</h2>
          <ul className="mb-2">
            {q.alternativas.map((alt, i) => (
              <li key={i} className="ml-4">({String.fromCharCode(65 + i)}) {alt}</li>
            ))}
          </ul>
          <button onClick={() => toggleAnswer(index)} className="text-blue-600 underline">
            {visibleAnswers[index] ? "Ocultar resposta" : "Mostrar resposta"}
          </button>
          {visibleAnswers[index] && <p className="mt-2 text-green-600 font-medium">Resposta correta: {q.resposta}</p>}
        </div>
      ))}
    </div>
  );
}