const questions = [
  {
    enunciado: "Exemplo de pergunta?",
    alternativas: ["Alternativa A", "Alternativa B", "Alternativa C", "Alternativa D"],
    resposta: "A"
  }
];
export default questions;