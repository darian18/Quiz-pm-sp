import React from 'react';
import QuestionPage from './pages/QuestionPage';
export default function App() { return <QuestionPage />; }